package physics;

public class Accel {
    private double ax, ay;

    public Accel(double ax, double ay) {
        this.ax = ax;
        this.ay = ay;
    }

    public double ax() {
        return this.ax;
    }

    public double ay() {
        return this.ay;
    }
}